/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication19;

import javax.swing.JOptionPane;

/**
 *
 * @author sebastianpadilla
 */
public class JavaApplication19 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int n = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de nodos"));
        int costo[][] = new int[n][n];
        for (int i = 0; i < n; i++) {
            
            for (int j = 0; j < n; j++) {
                if (i == j) {
                    costo[i][j] = 0;
                } else {
                        costo[i][j] = (int) (Math.random()*10);
                        costo[j][i] = costo[i][j];  
                }
                
            }
        }
        for (int i = 0; i < n; i++) {
            System.out.println("");
            for (int j = 0; j < n; j++) {
                System.out.print("[" + i + ", " + j + "] = " + costo[i][j] +"  ");
            }
        }
        int mat2[][] = new int[n][1];
        mat2 = dijkstra(costo, 0, 3, n);
    }
    
    public static int[][] dijkstra(int matriz[][], int inicio, int fin, int n){
        int mat2[][] = new int [n][1];
        boolean vec[] = new boolean[n];
        mat2[inicio][0] = 0;
        //mat2[inicio][1] = -1;
        int num = inicio;
        vec[inicio] = true;
        for (int k = 0; k < n-1; k++) {
            for (int i = 0; i < n; i++) {
                if(matriz[num][i] != 0){
                    if( recorrido(mat2, num, inicio) < mat2[num][1]){
                        mat2[num][1] = recorrido(mat2, num, inicio);
                    }
                    mat2[i][0] = num;
                }
                vec[num] = true;
            }
            int menor = 100000;
            for (int h = 0; h < n; h++) {
                if(mat2[h][1] < menor && vec[h] == false){
                    menor = mat2[h][1];
                    num = h;
                }
            }
        }
        return mat2;
    }
    
    public static int recorrido(int mat2[][], int num, int inicio){
        int cont= 0;
        while(num != inicio){
            cont += mat2[num][1];
            num = mat2[num][0];
        }
        return cont;
    }
}
